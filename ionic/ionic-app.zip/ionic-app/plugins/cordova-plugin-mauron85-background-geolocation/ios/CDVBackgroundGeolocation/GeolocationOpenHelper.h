//
//  GeolocationOpenHelper.h
//  CDVBackgroundGeolocation
//
//  Created by Marian Hello on 27/06/16.
//  Copyright © 2016 mauron85. All rights reserved.
//

#ifndef GeolocationOpenHelper_h
#define GeolocationOpenHelper_h

#import "SQLiteOpenHelper.h"

@interface GeolocationOpenHelper : SQLiteOpenHelper
@end

#endif /* GeolocationOpenHelper_h */
