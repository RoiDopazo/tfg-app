For development, cordova lib is required. You can copy it from any cordova project.

1. copy content of cordova lib into `CordovaLib`
2. add `CordovaLib/CordovaLib.xcodeproj` as project dependency
3. Add *CordovaLib* into project *Build Phases* -> *Target Dependencies* 

For more info visit https://cordova.apache.org/docs/en/2.5.0/guide/getting-started/ios/
