package com.marianhello.bgloc;

/**
 * Created by finch on 20/07/16.
 */
public interface UploadingCallback {
    void uploadListener(int progress);
}
